1. unzip the folder and save with the same name
2. save the SQL file in the HT DOX of  XAMPP  folder in C drive of your computer
3. import the SLQ file to xampp by directing through c drive/xampp/htdoc/SQL file
4. after importing , run the local server for checking
5. http://localhost/(the project name)
6. use the login credientials provided in the readme file in the folder
7. your project is ready to perform

8. thank you
